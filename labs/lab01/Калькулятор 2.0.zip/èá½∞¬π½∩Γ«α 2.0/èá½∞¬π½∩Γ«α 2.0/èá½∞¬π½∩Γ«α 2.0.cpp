﻿#include <iostream>
#include <corecrt_math.h>
double pluss(double x, double y)
{
    return(x + y);
}
double minuss(double x, double y)
{
    return(x - y);
}
double dels(double x, double y)
{
    return(x / y);
}
double ymns(double x, double y)
{
    return(x * y);
}
double steps(double x, double y)
{
    return(pow(x, y));
}
double calc_oper(double x, char oper, double y)
{
    double result = 0;
    switch (oper)
    {
    case '+':
        {
            result = pluss(x, y);
            break;
        }
    case '-':
        {
        result = minuss(x, y);
        break;
        }
    case '*':
        {
        result = ymns(x, y);
        break;
        }
    case '/':
        {
        result = dels(x, y);
        break;
        }
    case '^':
        {
        result = steps(x, y);
        break;
        }
    }
    return result;
}
void simpl_calc()
{
    while (true)
    {
        int x;
        std::cout << "Enter 1 number" << std::endl;
        std::cin >> x;
        while (std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "You didn't enter a number, try again!" << std::endl;
            std::cin >> x;
        }
        std::cout << "Enter 2 number" << std::endl;
        int y;
        std::cin >> y;
        while (std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "You didn't enter a number, try again!" << std::endl;
            std::cin >> y;
        }
        std::cout << "Enter calculator operation" << std::endl;
        char oper = '+';
        std::cin >> oper;
        char p=0;
        while (p != '1')
        {
            if (oper != '-' and oper != '+' and oper != '*' and oper != '/' and oper != '^')
            {
                std::cout << "You didn't enter calculator operation, try again!" << std::endl;
                std::cin >> oper;
            }
            else
                p = '1';
        }
        std::cout << calc_oper(x, oper, y) << std::endl;
        break;
    }
}
int mat_calc()
{
    int i, j, n, m, a[10][10], b[10][10], d[10][10], flag = 0;
    char m_op = '+';
    std::cout << "Enter the size of the matrix" << std::endl;
    std::cin >> m;
    std::cin >> n;
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            flag++;
            std::cout << "Enter the value number " << flag << std::endl;
            std::cout << "of A matrix " << std::endl;
            std::cin >> a[i][j];
            while (std::cin.fail())
            {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cout << "You didn't enter a number!" << std::endl;
                break;
            }
        }
    }
    flag = 0;
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            flag++;
            std::cout << "Enter the value number " << flag << std::endl;
            std::cout << "of B matrix " << std::endl;
            std::cin >> b[i][j];
            if (std::cin.fail())
            {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cout << "You didn't enter a number!" << std::endl;
                break;
            }
        }
    }
    flag = 0;
    std::cout << "Enter + or - " << std::endl;
    std::cin >> m_op;
    int q = 0;
    while (q == 0)
    {
        if (m_op != '-' and m_op != '+')
        {
            std::cout << "You didn't enter + or -, try again!" << std::endl;
            std::cin >> m_op;
        }
        else
            q = 1;
    }
    {
        for (i = 0; i < m; i++)
        {
            for (j = 0; j < n; j++)
            {
                if (m_op == '+')
                    d[i][j] = a[i][j] + b[i][j];
                else if (m_op == '-')
                    d[i][j] = a[i][j] - b[i][j];
            }
        }
    }
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n; j++)
        {
            std::cout << d[i][j] << " ";
        }
        std::cout << std::endl;
    }
    return 0;
}

int main()
{
    int end = 0;
    while (end == 0)
    {
        std::cout << "Calculator Console" << std::endl;
        std::cout << "Select operating mode. (1)-numerical calculator, (2)-matrix calculator" << std::endl;
        std::cout << "If you want to exit, press (3)" << std::endl;
        int z;
        std::cin >> z;
        while (std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "You didn't enter a number, try again!" << std::endl;
            std::cin >> z;
        }
        while (z != 1 and z != 2 and z!=3)
        {
            std::cout << "You didn't enter 1 or 2!" << std::endl;
            std::cin >> z;
            while (std::cin.fail())
            {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cout << "You didn't enter a number, try again!" << std::endl;
                std::cin >> z;
            }
        }
        if (z == 1)
            simpl_calc();
        if (z == 2)
            mat_calc();
        if (z == 3)
            break;
        std::cout << "if you want to continue, press 0" << std::endl;
        std::cin >> end;
    }
}

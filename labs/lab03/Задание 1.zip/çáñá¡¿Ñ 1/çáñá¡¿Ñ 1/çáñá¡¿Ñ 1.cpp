﻿#include <iostream>
#include <algorithm>
#include <climits>

// Definition for a binary tree node.
struct Tree {
    int val;
    Tree* left;
    Tree* right;
    Tree(int x) : val(x), left(nullptr), right(nullptr) {}
};
class Finder
{
public:
    int maxPathSum(Tree* root)
    {
        int max_sum = INT_MIN;
        maxPathSumHelper(root, max_sum);
        return max_sum;
    }
protected:
    int maxPathSumHelper(Tree* node, int& max_sum)
    {
        if (!node)
        {
            return 0;
        }
        // Recursively compute the maximum path sums in the left and right subtrees
        int left_max = std::max(0, maxPathSumHelper(node->left, max_sum));
        int right_max = std::max(0, maxPathSumHelper(node->right, max_sum));
        // Update the global maximum path sum
        max_sum = std::max(max_sum, left_max + right_max + node->val);
        // Return the maximum path sum starting from the current node
        return  std::max(left_max, right_max) + node->val;
    }
};
void main()
{
    Finder f;
    // Constructing the tree
    Tree* root = new Tree(-10);
    root->left = new Tree(9);
    root->right = new Tree(20);
    root->right->left = new Tree(15);
    root->right->right = new Tree(7);
    int result = f.maxPathSum(root);
    std::cout << "Maximum Path Sum: " << result << std::endl;
    //free allocated memory for the tree nodes
    delete root->left;
    delete root->right->left;
    delete root->right->right;
    delete root->right;
    delete root;
}
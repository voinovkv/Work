﻿#include <queue>
#include <iostream>
using namespace std;
int steak_check()
{
    int  steak;
    int z = 0;
    while (z == 0)
    {
        std::cin >> steak;
        if (std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Try again!" << std::endl;
        }
        else
            z = 1;
    }
    return steak;
}
int steak_check_plus()
{
    int  steak;
    int z = 0;
    while (z == 0)
    {
        std::cin >> steak;
        if (std::cin.fail() or steak<1)
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Try again!" << std::endl;
        }
        else
            z = 1;
    }
    return steak;
}
class MedianFinder 
{
private:
    priority_queue<int> MaxHeap;
    priority_queue<int, vector<int>, greater<int>> MinHeap;

public:
    void addNum(int num) 
    {
        if (MaxHeap.empty() || num < MaxHeap.top()) 
        {
            MaxHeap.push(num);
        }
        else 
        {
            MinHeap.push(num);
        }

        // Rebalance the heaps
        if (MaxHeap.size() > MinHeap.size() + 1) 
        {
            MinHeap.push(MaxHeap.top());
            MaxHeap.pop();
        }
        else if (MinHeap.size() > MaxHeap.size() + 1) 
        {
            MaxHeap.push(MinHeap.top());
            MinHeap.pop();
        }
    }

    double findMedian() 
    {
        if (MaxHeap.size() == MinHeap.size()) 
        {
            return (MaxHeap.top() + MinHeap.top()) / 2.0;
        }
        else if (MaxHeap.size() > MinHeap.size()) 
        {
            return MaxHeap.top();
        }
        else 
        {
            return MinHeap.top();
        }
    }
};
int main() 
{
    MedianFinder mf;
    cout << "Enter the number of numbers: ";
    int numofnum = steak_check_plus();
    int num;
    while (numofnum > 0)
    {
        cout << "Enter the number: ";
        num = steak_check();
        mf.addNum(num);
        numofnum = numofnum - 1;
    }
    double median = mf.findMedian();
    cout << "Median: " << median;
    return 0;
}
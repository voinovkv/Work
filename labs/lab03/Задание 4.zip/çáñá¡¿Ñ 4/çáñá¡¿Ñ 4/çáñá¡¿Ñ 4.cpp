﻿#include <iostream>
const int MAX_N = 9; // Maximum value of n

int steak_check()
{
    int  steak;
    int z = 0;
    while (z == 0)
    {
        std::cin >> steak;
        if (std::cin.fail() or steak>9 or steak<1)
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. n should be between 1 and 9 inclusive. Try again." << std::endl;
        }
        else
            z = 1;
    }
    return steak;
}

bool isSafe(char board[MAX_N][MAX_N], int row, int col, int n) 
{
    // Check vertical, horizontal, and diagonals
    for (int i = 0; i < row; ++i) 
    {
        if (board[i][col] == 'Q') 
        {
            return false; // Check vertical
        }
        if (col - (row - i) >= 0 && board[i][col - (row - i)] == 'Q') 
        {
            return false; // Check left diagonal
        }
        if (col + (row - i) < n && board[i][col + (row - i)] == 'Q') 
        {
            return false; // Check right diagonal
        }
    }
    return true;
}

void printBoard(char board[MAX_N][MAX_N], int n) 
{
    for (int i = 0; i < n; ++i) 
    {
        for (int j = 0; j < n; ++j) 
        {
            std::cout << board[i][j] << " ";
        }
        std::cout << std::endl;
    }
    std::cout << "-----------------" << std::endl;
}

void solver(int row, int n, char board[MAX_N][MAX_N]) 
{
    if (row == n) 
    {
        // Reached the final row, print the current configuration
        printBoard(board, n);
        return;
    }

    for (int col = 0; col < n; ++col) 
    {
        if (isSafe(board, row, col, n)) 
        {
            // Place the queen if the cell is safe
            board[row][col] = 'Q';
            solver(row + 1, n, board);
            board[row][col] = '.'; // Undo the choice to explore other options
        }
    }
}

void main() 
{
    int n;
    std::cout << "Enter the value of n (1-9): ";
    n = steak_check();
    char board[MAX_N][MAX_N];
    for (int i = 0; i < n; ++i) 
    {
        for (int j = 0; j < n; ++j) 
        {
            board[i][j] = '.'; // Initialize the board with empty cells
        }
    }
    solver(0, n, board);
}
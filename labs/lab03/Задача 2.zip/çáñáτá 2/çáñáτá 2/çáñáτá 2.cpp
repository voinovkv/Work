﻿#include <iostream>
#include <vector>
#include <unordered_map>
int steak_check()
{
    int  steak;
    int z = 0;
    while (z == 0)
    {
        std::cin >> steak;
        if (std::cin.fail())
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Try again!" << std::endl;
        }
        else
            z = 1;
    }
    return steak;
}
class Checker
{
public:
    bool containsNearbyAlmostDuplicate(std::vector<int>& nums, int indexDiff, int valueDiff) {
        if (nums.size() <= 1 || indexDiff <= 0 || valueDiff < 0) 
        {
            return false;
        }

        std::unordered_map<long long, long long> bucketMap;

        for (int i = 0; i < nums.size(); ++i) 
        {
            long long num = static_cast<long long>(nums[i]);

            // Bucketing to check valueDiff
            long long bucket = num / (static_cast<long long>(valueDiff) + 1);

            // Check for duplicates in the current bucket or neighboring buckets
            if (bucketMap.count(bucket) ||
                (bucketMap.count(bucket - 1) && abs(num - bucketMap[bucket - 1]) <= valueDiff) ||
                (bucketMap.count(bucket + 1) && abs(num - bucketMap[bucket + 1]) <= valueDiff)) 
            {
                return true;
            }

            // If the window size is exceeded, remove the leftmost element from the bucket
            if (i >= indexDiff) 
            {
                long long leftmostBucket = static_cast<long long>(nums[i - indexDiff]) / (static_cast<long long>(valueDiff) + 1);
                bucketMap.erase(leftmostBucket);
            }

            // Add the current element to the bucket
            bucketMap[bucket] = num;
        }

        return false;
    }
};

void main() {
    Checker Check;

    // User input for 'nums'
    int n;
    std::cout << "Enter the size of nums: ";
    n = steak_check();

    std::vector<int> nums(n);
    std::cout << "Enter the elements of nums:" << std::endl;
    for (int i = 0; i < n; ++i) 
    {
        nums[i]= steak_check();
    }

    int indexDiff, valueDiff;
    std::cout << "Enter indexDiff: ";
    indexDiff=steak_check();

    std::cout << "Enter valueDiff: ";
    valueDiff= steak_check();

    // Call the function
    bool result = Check.containsNearbyAlmostDuplicate(nums, indexDiff, valueDiff);

    std::cout << (result ? "true" : "false") << std::endl;
}

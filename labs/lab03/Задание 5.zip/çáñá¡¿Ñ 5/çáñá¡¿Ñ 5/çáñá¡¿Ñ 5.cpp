﻿#include <iostream>
#include <vector> //to create and manipulate dynamic arrays like matrices
#include <stack> //implements stack data structure
bool validInput(char c) 
{//to check user's input values
    return c == '0' || c == '1';
}
int steak_check_plus()
{
    int  steak;
    int z = 0;
    while (z == 0)
    {
        std::cin >> steak;
        if (std::cin.fail() or steak < 1 or steak > 200)
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Try again!" << std::endl;
        }
        else
            z = 1;
    }
    return steak;
}
int Rectangle(std::vector<std::vector<char>>& matrix) 
{//takes 2d vector, returns int
    if (matrix.empty() || matrix.size() == 0 || matrix[0].size() == 0) 
    {
        return 0;
    }

    int rows = matrix.size();
    int cols = matrix[0].size();

    // Check conditions
    if (rows == matrix.size() && cols == matrix[0].size() && rows >= 1 && rows <= 200 && cols >= 1 && cols <= 200) 
    {
        std::vector<int> heights(cols, 0);
        int maxArea = 0;//initialize var to store max area

        for (int i = 0; i < rows; ++i) 
        {
            for (int j = 0; j < cols; ++j) 
            {
                char input;
                do 
                {
                    std::cout << "Enter value (0 or 1) for matrix[" << i << "][" << j << "]: ";
                    std::cin >> input;

                    if (!validInput(input)) 
                    {
                        std::cout << "Invalid input. Please enter '0' or '1'." << std::endl;
                    }
                } while (!validInput(input));

                matrix[i][j] = input;
            }
        }

        for (int i = 0; i < rows; ++i) 
        {
            for (int j = 0; j < cols; ++j) 
            {
                if (matrix[i][j] == '1') 
                {
                    heights[j] += 1;
                }
                else 
                {
                    heights[j] = 0;
                }
            }

            std::stack<int> s;
            for (int j = 0; j <= cols; ++j) 
            {
                while (!s.empty() && (j == cols || heights[j] < heights[s.top()])) 
                {
                    int height = heights[s.top()];
                    s.pop();
                    int width = s.empty() ? -1 : s.top();
                    maxArea = std::max(maxArea, height * (j - width - 1));
                }
                s.push(j);
            }
        }

        return maxArea;
    }
    else 
    {
        std::cout << "Invalid input size or range." << std::endl;
        return 0;
    }
}

int main() 
{
    int rows, cols;
    std::cout << "Enter the number of rows (1-200): ";
    rows= steak_check_plus();
    std::cout << "Enter the number of columns (1-200): ";
    cols=steak_check_plus();

    std::vector<std::vector<char>> matrix(rows, std::vector<char>(cols, '0'));

    int result = Rectangle(matrix);
    std::cout << "Maximum rectangle area: " << result << std::endl;

    return 0;
}
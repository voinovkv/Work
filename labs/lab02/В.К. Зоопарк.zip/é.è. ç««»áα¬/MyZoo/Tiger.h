﻿#pragma once
#include <iostream>
#include <string>
#include "Animal.h"

class Tiger : public Animal
{
public:
	Tiger(std::string name, std::string reaction, double weight)
		:Animal(name, reaction, weight, "Tiger")
	{}

	void GetInfo() const override
	{
		std::cout << _type + " name: " + _name + "\n" << "Weight: " + std::to_string(_weight) + "\n";
		std::cout << "Wants to eat" << std::endl;
	}
	void ReactAsTiger()
	{
		std::cout << "It tastes good to the tiger\n";
	}
	void ReactAsTiger2()
	{
		std::cout << "RRRRRrrrrRRRR!!!\n";
	}
};

class Elephant : public Animal
{
public:
	Elephant(std::string name, std::string reaction, double weight)
		:Animal(name, reaction, weight, "Elephant")
	{}
	void GetInfo() const override
	{
		std::cout << _type+ " name: " + _name + "\n" << "Weight: " + std::to_string(_weight) + "\n";
		std::cout << "Very big elephant" << std::endl;
	}
	void ReactAsElephant()
	{
		std::cout << "The elephant ran away\n";
	}
	void ReactAsElephant2()
	{
		std::cout << "The elephant ate the whole cabbage!\n";
	}
};

class Squirrel : public Animal
{
public:
	Squirrel(std::string name, std::string reaction, double weight)
		:Animal(name, reaction, weight, "Squirrel")
	{}
	void GetInfo() const override
	{
		std::cout << _type + " name: " + _name + "\n" << "Weight: " + std::to_string(_weight) + "\n";
		std::cout << "Very small squirrel" << std::endl;
	}
	void ReactAsSquirrel()
	{
		std::cout << "The squirrel stole the nut!\n";
	}
	void ReactAsSquirrel2()
	{
		std::cout << "Squirrels in your pants!\n";
	}
};